#!/bin/sh

JAR_SIGNER_JDK=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.332.b09-0.x86_64
KEY_TOOL_JRE=$JAR_SIGNER_JDK/jre
KEY_TOOL=$KEY_TOOL_JRE/bin/keytool
JAR_SIGNER=$JAR_SIGNER_JDK/bin/jarsigner
PROVIDER=JCP
STORE_TYPE=HDImageStore
KEY_PASS=11111111
KEY_ALIAS=myGostKey
DN_NAME=CN=myGostKey,O=CryptoPro,C=RU
COPY_STORE_TYPE=HDImageStore
COPY_KEY_ALIAS=myGostKeyCopy
COPY_KEY_PASS=00000000
REQUEST_FILE=request_gost.bin
P7B_FILE=certnew_gost.p7b
EXPORT_CERT=myGostKeyCert.cer
NEW_PASSWORD=12345678
JAR_FILE=test.jar
SIGNED_JAR_FILE=test.signed.jar
TRUST_STORE=trust_for_jar_signer
PARAM=-J-Dkeytool.compat=true -J-Duse.cert.stub=true

echo "1. List containers:"
$KEY_TOOL $PARAM -list -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Listing completed."

read -p "hit Enter to continue"

echo "1*. Control deleting copy-container:"
$KEY_TOOL $PARAM -delete -alias $KEY_ALIAS -providername $PROVIDER -storetype $COPY_STORE_TYPE -keystore NONE -storepass 1
echo "Control deleting completed."

read -p "hit Enter to continue"

echo "1**. Control deleting copy-container:"
$KEY_TOOL $PARAM -delete -alias $COPY_KEY_ALIAS -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Control deleting completed."

read -p "hit Enter to continue"

echo "2. Generating key pair:"
$KEY_TOOL $PARAM -genkey -alias $KEY_ALIAS -keysize 512 -providername $PROVIDER -storetype $STORE_TYPE -dname $DN_NAME -keystore NONE -storepass 1 -keyalg GOST3410_2012_256 -sigalg GOST3411_2012_256withGOST3410_2012_256 -keypass $KEY_PASS
echo "Generating pair completed."

read -p "hit Enter to continue"

echo "3. Creating certificate request:"
$KEY_TOOL $PARAM -certreq -alias $KEY_ALIAS -providername $PROVIDER -keypass $KEY_PASS -storetype $STORE_TYPE -keystore NONE -storepass 1 -sigalg GOST3411_2012_256withGOST3410_2012_256 -file $REQUEST_FILE
echo "Creating request completed."

read -p "hit Enter to continue"

echo "4. Creating self-signed certificate:"
$KEY_TOOL $PARAM -selfcert -alias $KEY_ALIAS -providername $PROVIDER -keypass $KEY_PASS -storetype $STORE_TYPE -keystore NONE -storepass 1 -sigalg GOST3411_2012_256withGOST3410_2012_256 -dname $DN_NAME
echo "Creating certificate completed."

echo "5. Please, use certificate request %REQUEST_FILE%, send it to CA, retreive and save to file %P7B_FILE%"
read -p "hit Enter to continue"

echo "6. Importing certificate chain (p7b):"
echo $KEY_TOOL $PARAM -import -alias $KEY_ALIAS -providername $PROVIDER -keypass $KEY_PASS -storetype $STORE_TYPE -keystore NONE -storepass 1 -file $P7B_FILE -noprompt
$KEY_TOOL $PARAM -import -alias $KEY_ALIAS -providername $PROVIDER -keypass $KEY_PASS -storetype $STORE_TYPE -keystore NONE -storepass 1 -file $P7B_FILE -noprompt
echo "Importing chain completed."

read -p "hit Enter to continue"

echo "7. Exporting certificate:"
$KEY_TOOL $PARAM -export -alias $KEY_ALIAS -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1 -file $EXPORT_CERT
echo "Exporting certificate completed."

read -p "hit Enter to continue"

echo "8. Changing password:"
$KEY_TOOL $PARAM -keypasswd -alias $KEY_ALIAS -keypass $KEY_PASS -new $NEW_PASSWORD -storetype $STORE_TYPE -keystore NONE -storepass 1 -providername $PROVIDER
echo "Changing password completed."

read -p "hit Enter to continue"

@rem �.�. ���� ������ ��� ��������� ����������, ������ ����� -destkeypass, ����� ��� ���� ������ ��������� ����������
echo "9. Copy container:"
$KEY_TOOL $PARAM -importkeystore -srckeystore $TRUST_STORE -srcstoretype $STORE_TYPE -srcstorepass 1 -destkeystore NONE -deststoretype $COPY_STORE_TYPE -deststorepass 1 -srcprovidername $PROVIDER -destprovidername $PROVIDER -srcalias $KEY_ALIAS -srckeypass $NEW_PASSWORD -destalias $COPY_KEY_ALIAS
echo "Copying completed."

echo "10. Please, put jar-file %JAR_FILE% before signing and install Java CSP into JDK %JAR_SIGNER_JDK%"
read -p "hit Enter to continue"

echo "11. Signing jar:"
$JAR_SIGNER $PARAM -keystore NONE -storepass 1 -storetype $COPY_STORE_TYPE -signedjar $SIGNED_JAR_FILE -digestalg GOST3411_2012_256 -sigalg GOST3411_2012_256withGOST3410_2012_256 -providerName $PROVIDER -keypass $NEW_PASSWORD $JAR_FILE $COPY_KEY_ALIAS
echo "Signing jar completed."
 
read -p "hit Enter to continue"
 
echo "12. Verifying signed jar:"
$JAR_SIGNER $PARAM -verify $SIGNED_JAR_FILE
echo "Verifying completed."

read -p "hit Enter to continue"

echo "13. Deleting container:"
$KEY_TOOL $PARAM -delete -alias $KEY_ALIAS -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Deleting container completed."

read -p "hit Enter to continue"

echo "14. Deleting copy-container:"
$KEY_TOOL $PARAM -delete -alias $COPY_KEY_ALIAS -providername $PROVIDER -storetype $COPY_STORE_TYPE -keystore NONE -storepass 1
echo "Deleting copy-container completed."
