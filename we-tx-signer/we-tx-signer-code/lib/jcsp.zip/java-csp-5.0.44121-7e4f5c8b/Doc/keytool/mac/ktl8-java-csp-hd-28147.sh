#!/bin/sh

KEY_TOOL_JRE=/Library/Java/JavaVirtualMachines/jdk1.8.0_301.jdk/Contents/Home
KEY_TOOL=$KEY_TOOL_JRE/bin/keytool

PROVIDER=JCSP
PROVIDER_CLASS=ru.CryptoPro.JCSP.JCSP
STORE_TYPE=HDIMAGE
KEY_PASS=11111111

# GOST28147 GOST3412_2015_M GOST3412_2015_K
ALG=GOST28147

KEY_ALIAS="my${ALG}NoPass"
COPY_KEY_ALIAS="my${ALG}CopyNoPass"
TRUST_STORE=trust_for_jar_signer
PARAM=-J-Dkeytool.compat=true

echo "1. List containers:"
$KEY_TOOL $PARAM -list -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Listing completed."

read -p "hit Enter to continue "

echo "1*. Control deleting container:"
$KEY_TOOL $PARAM -delete -alias $KEY_ALIAS -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Control deleting completed."

read -p "hit Enter to continue "

echo "1**. Control deleting copy-container:"
$KEY_TOOL $PARAM -delete -alias $COPY_KEY_ALIAS -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1
echo "Control deleting completed."

read -p "hit Enter to continue "

echo "2. Generating key:"
#$KEY_TOOL $PARAM -genseckey -alias $KEY_ALIAS -keysize 256 -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -keyalg $ALG -protected
$KEY_TOOL $PARAM -genseckey -alias $KEY_ALIAS -keysize 256 -providername $PROVIDER -storetype $STORE_TYPE -keystore NONE -storepass 1 -keyalg $ALG -keypass $KEY_PASS
echo "Generating secret key completed."

read -p "hit Enter to continue "

echo "3. Copy container:"
#$KEY_TOOL $PARAM -importkeystore -srcprotected -srckeystore $TRUST_STORE -srcstoretype $STORE_TYPE -destkeystore NONE -deststoretype $STORE_TYPE -deststorepass 1 -srcprovidername $PROVIDER -destprovidername $PROVIDER -srcalias $KEY_ALIAS -destalias $COPY_KEY_ALIAS
$KEY_TOOL $PARAM -importkeystore -srckeystore $TRUST_STORE -srcstoretype $STORE_TYPE -srcstorepass $KEY_PASS -destkeystore NONE -deststoretype $STORE_TYPE -deststorepass 1 -srcprovidername $PROVIDER -destprovidername $PROVIDER -srcalias $KEY_ALIAS -destalias $COPY_KEY_ALIAS
echo "Copying completed."
echo "Finished"